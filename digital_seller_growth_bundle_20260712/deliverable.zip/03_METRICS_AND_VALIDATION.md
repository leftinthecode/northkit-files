# Metrics And Validation

Track before and after each change.

| Date | Product | Change | Views | Saves/Favorites | Clicks | Orders | Buyer Questions | Next Fix |
|---|---|---|---:|---:|---:|---:|---|---|

## Decision rules

- Views but no clicks: fix preview/title/offer.
- Clicks but no orders: fix page, price, proof, included files, and trust.
- Orders with repeated questions: improve onboarding and FAQ.
- No views: improve traffic source and keyword/pin strategy.
