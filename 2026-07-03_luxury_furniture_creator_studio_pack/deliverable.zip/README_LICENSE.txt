Luxury Furniture + Creator Studio Prop Pack

Royalty-free original GLB environment/prop pack created for Nash VSW.

Included:
- GLB export
- Blender source
- Four preview renders
- QA manifest
- Listing metadata

Allowed: commercial use in renders, prototypes, web previews, games, and AR scenes.
Not included: trademarked logos, protected brand marks, or platform upload guarantees.
