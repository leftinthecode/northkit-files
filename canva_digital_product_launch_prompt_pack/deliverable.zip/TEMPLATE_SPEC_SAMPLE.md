# Sample Canva Template Spec

Product: Digital Product Idea Validation Worksheet

Buyer: beginner creator who has too many ideas and needs to pick one product to build first.

Pages:
- Cover page with clear outcome.
- Buyer problem scoring sheet.
- Offer promise worksheet.
- Included files checklist.
- Preview image planning page.
- Launch readiness checklist.

Design direction:
- Clean, print-friendly layout.
- Large headings and generous writing space.
- Avoid tiny text and decorative clutter.
- Export as PDF plus listing preview images.