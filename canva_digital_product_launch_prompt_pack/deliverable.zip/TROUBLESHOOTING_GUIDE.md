# Troubleshooting Guide

## The AI Output Is Too Generic

Add a clearer buyer persona, specific buyer problem, product type, page count, and platform. Rerun the prompt with one narrow outcome.

## The Canva Product Feels Like Filler

Use the page keep/cut prompt. Remove pages that only repeat advice. Replace them with pages where the buyer writes, checks, plans, scores, or decides.

## The Listing Sounds Too Hype-Heavy

Remove income, ranking, and traffic promises. Replace them with concrete deliverables and realistic buyer outcomes.

## The Design Looks Amateur

Reduce colors, use consistent spacing, align elements, limit fonts, and make the first preview show the product clearly.

## Buyers Might Not Know What To Do

Add a Start Here page, file list, use order, Canva access instructions, and a short FAQ.

## The Product Is Not Selling

Check metrics first. If views are low, improve SEO and traffic. If clicks are low, improve cover/title. If checkout is weak, improve proof, previews, delivery clarity, and offer value.

