# Advanced Seller Path

This path is for a seller improving an existing Canva product, template shop, or bundle.

## Step 1: Audit The Existing Product

Use the copy audit, no-filler scope, and page keep/cut prompts. Remove weak pages before adding more.

## Step 2: Build A Better Offer

Use product ladder prompts to define basic, premium, and bundle versions. Do not bundle weak pages.

## Step 3: Strengthen Preview Proof

Use preview image direction prompts. Show page variety, buyer outcome, and included files.

## Step 4: Improve Listing Conversion

Use listing prompts, then compare views, clicks, saves, carts, and sales in `METRICS_TRACKER_TEMPLATE.md`.

## Step 5: Support And Reduce Refund Risk

Use FAQ, troubleshooting, export, and buyer instruction prompts. Make the download easy to use without contacting support.

