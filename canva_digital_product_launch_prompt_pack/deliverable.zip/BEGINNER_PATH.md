# Beginner Path

This path is for a seller who has an idea but no finished Canva product.

## Step 1: Pick One Buyer Problem

Fill out `BUYER_INPUT_WORKSHEET.md`. Keep the problem narrow.

## Step 2: Create A Page Plan

Use a Product Idea To Page Plan prompt. Choose the smallest useful product.

## Step 3: Write The First Useful Pages

Use Canva Page Copy And Structure prompts. Build only pages that help the buyer complete a task.

## Step 4: Create The Visual Direction

Use the visual direction prompts before designing. Decide format, page size, style, and preview plan.

## Step 5: Export And Check

Use `EXPORT_CHECKLIST.md` and `AI_OUTPUT_QA_CHECKLIST.md`.

## Step 6: Draft The Listing

Use listing prompts, then verify every claim with `CLAIMS_DELIVERY_MAP.md`.

