# Metrics Tracker Template

Track results before changing the product. Use evidence, not guesses.

| Date | Platform | Product Version | Views | Clicks | Saves/Favorites | Cart/Adds | Sales | Refunds | Notes |
|---|---|---|---:|---:|---:|---:|---:|---:|---|
| YYYY-MM-DD | Gumroad/Etsy/Pinterest/Instagram | v1 | 0 | 0 | 0 | 0 | 0 | 0 | Baseline |

## What To Watch

High views and low clicks:

Improve cover, title, first preview, and benefit clarity.

High clicks and no sales:

Improve price, included files, product proof, preview detail, and checkout trust.

Sales with support questions:

Improve instructions, FAQ, file naming, and delivery structure.

Refunds:

Check whether the listing promised something the product does not deliver.

## Change Rule

Change one major thing at a time, then wait long enough to compare. Do not repost duplicate social content just because early results are quiet.

