# Start Here

This digital product is built for sellers who want a clearer workflow before changing a listing, template, pin plan, support system, or bundle offer.

## Fastest Path

1. Open `BUYER_INPUT_WORKSHEET.md` and fill in one narrow product idea.
2. Use `PROMPT_SELECTION_MAP.md` to choose the right prompt group.
3. Follow either `BEGINNER_PATH.md` or `ADVANCED_SELLER_PATH.md`.
4. Run one prompt at a time and save the before version, prompt output, final edit, and date changed.
5. Use `AI_OUTPUT_QA_CHECKLIST.md`, `CLAIMS_DELIVERY_MAP.md`, and `EXPORT_CHECKLIST.md` before publishing any public change.
6. Track results in `METRICS_TRACKER_TEMPLATE.md` before changing the product again.

## Product

56+ Canva Digital Product Launch ChatGPT Prompts for Template Creators

## Important

This is a digital download. It does not guarantee sales, traffic, ranking, income, platform approval, or customer reactions.
