# Canva Export Checklist

- [ ] All pages have useful buyer tasks, not filler.
- [ ] Text is readable on phone preview and printed PDF.
- [ ] Cover and preview images match the actual included files.
- [ ] PDF export opens locally before platform upload.
- [ ] Buyer instructions explain Canva access or non-editable PDF limits.
- [ ] Listing avoids income guarantees and unsupported claims.
- [ ] Delivery ZIP contains the PDF, instructions, and support notes.
