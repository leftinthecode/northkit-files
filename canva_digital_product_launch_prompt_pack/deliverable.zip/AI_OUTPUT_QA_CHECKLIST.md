# AI Output QA Checklist

Do not paste AI output directly into a product or listing. Review every output first.

## Accuracy

- The output matches your actual product.
- The page count, file types, and delivery details are correct.
- The buyer instructions match the final files.
- No unsupported claims were added.

## Usefulness

- Each page has a clear job.
- The instructions are specific enough for a beginner.
- The product solves one buyer problem clearly.
- Any examples are realistic and easy to adapt.

## Brand And Legal Safety

- No copied competitor language.
- No trademarked brand names used as product claims.
- No promise of guaranteed sales, traffic, ranking, approval, or income.
- No fake testimonials or fake scarcity.

## Design Readiness

- Copy is short enough to fit a Canva page.
- Headings and labels are clear.
- The buyer knows what to write, check, or complete.
- The preview images can show the value quickly.

## Publish Readiness

- Delivery files open correctly.
- Preview images match the product.
- Listing text matches the download.
- Refund/support instructions are clear.

