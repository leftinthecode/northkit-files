# 10 Minute Example Run

This example shows how to use the pack quickly.

## Inputs

Buyer persona: new Etsy seller

Buyer problem: wants to create a printable order tracker but does not know what pages to include

Product type: Canva printable tracker

Skill level: beginner

Price range: low-ticket digital download

## Prompt To Run First

Use a Product Idea To Page Plan prompt and replace the bracketed inputs with the details above.

## What A Good Output Should Include

- A focused page list
- A clear buyer outcome
- File/export recommendation
- Common mistakes to avoid
- A simple next action list

## Next Prompt

Run a Canva Page Copy And Structure prompt for the first worksheet page.

## QA Before Building

Ask:

- Would a buyer know what to do on every page?
- Does this product solve one clear problem?
- Are any claims too broad?
- Can the first preview image show the value quickly?

