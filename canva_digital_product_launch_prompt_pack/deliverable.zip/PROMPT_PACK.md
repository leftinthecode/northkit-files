# Canva Digital Product Launch AI Prompt Pack

A focused workflow prompt pack for turning one digital product idea into a Canva-ready worksheet, checklist, planner, or template launch plan. It helps buyers plan useful pages, write buyer instructions, create listing copy, and avoid filler. It does not guarantee sales.

## Product Idea To Page Plan

### 1. Prompt

Act as a Canva digital product strategist with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: turn [BUYER_PROBLEM] into a simple Canva digital product with page list, buyer outcome, and first-use path for [CANVA/ETSY_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: a product spec. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

### 2. Prompt

Act as a Canva digital product strategist with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: score 10 Canva product ideas by buyer pain, production speed, proof strength, and repeat-use potential for [CANVA/ETSY_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: ranked go/no-go table. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

### 3. Prompt

Act as a Canva digital product strategist with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: narrow [BROAD_IDEA] into a buyer-specific worksheet, checklist, planner, or template offer for [CANVA/ETSY_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: 5 focused offer options. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

### 4. Prompt

Act as a Canva digital product strategist with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: define the minimum useful version of [CANVA_PRODUCT] that can be built without filler pages for [CANVA/ETSY_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: MVP scope. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

### 5. Prompt

Act as a Canva digital product strategist with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: write a value promise for [CANVA_PRODUCT] that is specific and avoids income guarantees for [CANVA/ETSY_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: 5 promise options. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

### 6. Prompt

Act as a Canva digital product strategist with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: choose the best file format and delivery structure for [CANVA_PRODUCT] for [CANVA/ETSY_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: file/export recommendation. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

### 7. Prompt

Act as a Canva digital product strategist with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: map [CANVA_PRODUCT] into basic, premium, and bundle versions for [CANVA/ETSY_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: product ladder. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

### 8. Prompt

Act as a Canva digital product strategist with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: reject weak pages from [PAGE_LIST] and replace them with pages a buyer will actually use for [CANVA/ETSY_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: page keep/cut table. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

## Canva Page Copy And Structure

### 1. Prompt

Act as a worksheet and template copy designer with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: write page-by-page copy for a [WORKSHEET] helping [BUYER_PERSONA] complete [OUTCOME] for [CANVA/ETSY_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: page copy set. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

### 2. Prompt

Act as a worksheet and template copy designer with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: turn [PROCESS] into a printable checklist with clear completion criteria for [CANVA/ETSY_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: checklist content. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

### 3. Prompt

Act as a worksheet and template copy designer with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: create instruction text for buyers with no design experience using [TEMPLATE] for [CANVA/ETSY_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: plain-English instructions. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

### 4. Prompt

Act as a worksheet and template copy designer with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: write placeholder text for a Canva template so buyers know exactly what to replace for [CANVA/ETSY_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: template placeholder copy. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

### 5. Prompt

Act as a worksheet and template copy designer with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: design a one-page quick-win worksheet for [BUYER_PROBLEM] for [CANVA/ETSY_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: worksheet content. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

### 6. Prompt

Act as a worksheet and template copy designer with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: write cover, section divider, and back-page copy for [CANVA_PRODUCT] for [CANVA/ETSY_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: brand-safe copy. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

### 7. Prompt

Act as a worksheet and template copy designer with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: audit [PAGE_COPY] for filler, vague wording, and steps that are too hard for beginners for [CANVA/ETSY_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: copy audit. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

### 8. Prompt

Act as a worksheet and template copy designer with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: convert a long guide into 5 Canva worksheet pages with concise prompts and fields for [CANVA/ETSY_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: page reduction plan. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

## Visual Direction And Template Specs

### 1. Prompt

Act as a Canva visual product director with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: create a visual style spec for [CANVA_PRODUCT] including layout, type scale, color direction, and spacing for [CANVA/ETSY_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: style guide. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

### 2. Prompt

Act as a Canva visual product director with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: write a page-by-page Canva build spec for [CANVA_PRODUCT] for [CANVA/ETSY_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: template spec. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

### 3. Prompt

Act as a Canva visual product director with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: design cover image copy that proves usefulness in under 5 seconds for [CANVA/ETSY_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: cover copy options. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

### 4. Prompt

Act as a Canva visual product director with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: plan 6 listing preview images that show actual pages without giving away the full product for [CANVA/ETSY_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: preview image brief. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

### 5. Prompt

Act as a Canva visual product director with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: audit [TEMPLATE_NOTES] for unreadable text, weak hierarchy, and poor mobile preview for [CANVA/ETSY_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: visual usability audit. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

### 6. Prompt

Act as a Canva visual product director with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: choose between minimalist, luxe, playful, and professional styles for [BUYER_PERSONA] for [CANVA/ETSY_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: style decision memo. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

### 7. Prompt

Act as a Canva visual product director with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: write export instructions for PDF, PNG previews, and buyer-access notes for [CANVA/ETSY_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: export checklist. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

### 8. Prompt

Act as a Canva visual product director with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: create a simple brand consistency checklist for a Canva template bundle for [CANVA/ETSY_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: QA checklist. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

## Listing And Offer Copy

### 1. Prompt

Act as a digital download listing copywriter with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: write a title for [CANVA_PRODUCT] that states buyer, use case, and file type clearly for [CANVA/ETSY_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: 10 title options. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

### 2. Prompt

Act as a digital download listing copywriter with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: write a product description with who it is for, what is included, how to use it, and limits for [CANVA/ETSY_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: sectioned listing copy. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

### 3. Prompt

Act as a digital download listing copywriter with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: turn included pages into benefit-led bullets a buyer can understand quickly for [CANVA/ETSY_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: benefit bullets. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

### 4. Prompt

Act as a digital download listing copywriter with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: write an FAQ that explains digital download delivery and Canva usage limits for [CANVA/ETSY_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: FAQ section. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

### 5. Prompt

Act as a digital download listing copywriter with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: create 13 Etsy tags for [CANVA_PRODUCT] without stuffing for [CANVA/ETSY_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: tag table. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

### 6. Prompt

Act as a digital download listing copywriter with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: write honest expectation language for [CANVA_PRODUCT] for [CANVA/ETSY_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: policy-safe copy. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

### 7. Prompt

Act as a digital download listing copywriter with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: build a launch offer stack with real utility bonuses only for [CANVA/ETSY_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: offer stack. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

### 8. Prompt

Act as a digital download listing copywriter with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: audit listing copy for unsupported promises and confusing delivery expectations for [CANVA/ETSY_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: claim and clarity audit. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

## Buyer Instructions And Support

### 1. Prompt

Act as a digital product customer success lead with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: write buyer onboarding steps for using [CANVA_PRODUCT] in the first 10 minutes for [CANVA/ETSY_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: quick-start guide. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

### 2. Prompt

Act as a digital product customer success lead with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: create troubleshooting copy for Canva access, PDF downloads, and printing issues for [CANVA/ETSY_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: support guide. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

### 3. Prompt

Act as a digital product customer success lead with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: write a file map explaining every included file and when to use it for [CANVA/ETSY_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: file map. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

### 4. Prompt

Act as a digital product customer success lead with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: create refund-safe expectation language for editable templates for [CANVA/ETSY_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: support-safe policy note. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

### 5. Prompt

Act as a digital product customer success lead with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: write a feedback request that helps improve the product without pressuring reviews for [CANVA/ETSY_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: feedback message. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

### 6. Prompt

Act as a digital product customer success lead with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: audit [BUYER_INSTRUCTIONS] for beginner confusion for [CANVA/ETSY_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: instruction audit. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

### 7. Prompt

Act as a digital product customer success lead with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: write update notes for improving [CANVA_PRODUCT] after customer questions for [CANVA/ETSY_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: version update note. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

### 8. Prompt

Act as a digital product customer success lead with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: create a buyer quick-win challenge using [CANVA_PRODUCT] for [CANVA/ETSY_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: quick-win sequence. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

## Traffic And Validation

### 1. Prompt

Act as a Pinterest and Etsy traffic analyst with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: write 10 Pinterest pin titles and descriptions for [CANVA_PRODUCT] without duplicate spam for [CANVA/ETSY_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: pin drafts. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

### 2. Prompt

Act as a Pinterest and Etsy traffic analyst with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: create a 14-day launch test using views, saves, clicks, favorites, and sales for [CANVA/ETSY_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: test plan. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

### 3. Prompt

Act as a Pinterest and Etsy traffic analyst with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: define the minimum evidence needed before making more Canva products in this sub-niche for [CANVA/ETSY_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: validation threshold. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

### 4. Prompt

Act as a Pinterest and Etsy traffic analyst with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: turn [CANVA_PRODUCT] into 5 educational social posts showing the problem and solution for [CANVA/ETSY_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: post drafts. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

### 5. Prompt

Act as a Pinterest and Etsy traffic analyst with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: diagnose whether low views or low conversion is the bigger issue for [METRICS] for [CANVA/ETSY_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: metrics diagnosis. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

### 6. Prompt

Act as a Pinterest and Etsy traffic analyst with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: write a pivot rule if [CANVA_PRODUCT] gets traffic but no buyers for [CANVA/ETSY_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: pivot decision. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

### 7. Prompt

Act as a Pinterest and Etsy traffic analyst with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: build keyword clusters across Etsy, Pinterest, and Google for [CANVA_PRODUCT] for [CANVA/ETSY_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: keyword map. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

### 8. Prompt

Act as a Pinterest and Etsy traffic analyst with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: create a weekly improvement loop for a Canva digital product storefront for [CANVA/ETSY_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: operating cadence. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

## Quality Gate And No-Filler Audit

### 1. Prompt

Act as a digital product QA auditor with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: grade [CANVA_PRODUCT] against buyer outcome, page usefulness, preview proof, delivery clarity, and support risk for [CANVA/ETSY_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: 100-point scorecard. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

### 2. Prompt

Act as a digital product QA auditor with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: find filler pages in [PAGE_LIST] and suggest useful replacements for [CANVA/ETSY_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: filler audit. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

### 3. Prompt

Act as a digital product QA auditor with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: write release criteria before [CANVA_PRODUCT] can be listed for [CANVA/ETSY_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: pre-publish gate. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

### 4. Prompt

Act as a digital product QA auditor with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: compare [CANVA_PRODUCT] to [COMPETITOR_PRODUCT] on value-add without copying for [CANVA/ETSY_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: value-gap report. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

### 5. Prompt

Act as a digital product QA auditor with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: create a proof manifest listing source files, previews, instructions, and limitations for [CANVA/ETSY_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: proof manifest. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

### 6. Prompt

Act as a digital product QA auditor with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: audit [CANVA_PRODUCT] for trademark misuse, income claims, and unclear buyer rights for [CANVA/ETSY_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: risk audit. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

### 7. Prompt

Act as a digital product QA auditor with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: write a final pre-publish checklist requiring real preview and delivery proof for [CANVA/ETSY_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: checklist. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

### 8. Prompt

Act as a digital product QA auditor with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: create a post-launch learning plan from buyer questions and analytics for [CANVA/ETSY_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: learning plan. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.
