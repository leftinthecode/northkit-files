# Prompt Selection Map

Use this map to pick the right prompt instead of running the whole pack at once.

## If You Only Have An Idea

Start with:

- Product Idea To Page Plan
- Product ladder
- Weak page keep/cut table

Goal: choose one product a real buyer can use, not a broad bundle full of filler.

## If You Need The Canva Pages

Start with:

- Page-by-page copy
- Printable checklist content
- One-page quick-win worksheet
- Placeholder text

Goal: create pages that are useful before they are beautiful.

## If You Need The Visual Direction

Start with:

- Visual Direction And Template Specs
- Cover concept
- Preview image direction
- Brand-safe style system

Goal: make the product look clean, current, and easy to preview.

## If You Need A Listing

Start with:

- Listing title options
- Description draft
- Tag research direction
- Buyer instruction copy

Goal: explain what the buyer gets without income claims or vague hype.

## If You Need Delivery And Support

Start with:

- Export structure
- Buyer access instructions
- FAQ
- Troubleshooting

Goal: reduce refunds and support messages.

## If You Need To Improve A Weak Product

Start with:

- Copy audit
- Page keep/cut table
- No-filler scope
- Preview audit

Goal: replace weak pages, vague copy, and confusing delivery before publishing.

