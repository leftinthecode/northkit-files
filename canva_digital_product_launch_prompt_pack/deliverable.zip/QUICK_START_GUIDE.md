# Canva Digital Product Launch Quick Start

Use this pack when you have an idea for a worksheet, checklist, planner, tracker, or template but need a clean build plan.

## 15 Minute First Win

1. Choose one buyer problem and one product type.
2. Fill in `BUYER_INPUT_WORKSHEET.md` so the prompts have specific context.
3. Run a `Product Idea To Page Plan` prompt to make a focused page list.
4. Run one `Canva Page Copy And Structure` prompt for the first useful worksheet.
5. Run a `Visual Direction And Template Specs` prompt before designing in Canva.
6. Check the result with `AI_OUTPUT_QA_CHECKLIST.md`.
7. Do not list the product until preview images, buyer instructions, and delivery files match.

## Inputs To Gather

- Buyer persona and the task they want to finish.
- Product type: worksheet, checklist, planner, tracker, template, or bundle.
- Preferred style direction and platform where it will be sold.
- Included pages/files and any Canva access instructions.

## No-Guesswork Rule

If an output makes a claim about sales, traffic, ranking, approval, or income, remove it. This pack helps structure and improve a digital product workflow; it does not guarantee market results.
