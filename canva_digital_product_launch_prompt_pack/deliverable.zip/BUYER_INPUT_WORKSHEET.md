# Buyer Input Worksheet

Use this before running the prompts. Better inputs create cleaner outputs and reduce wasted Canva build time.

## Core Product Inputs

Product idea:

Buyer persona:

Buyer problem:

Main outcome the buyer should get:

Product type:

Price range:

Skill level:

Time available to build:

Platform where it will be sold:

## Buyer Use Case

What is the buyer trying to finish?

What makes this painful or time-consuming today?

What should be easier after they download your product?

What should the product avoid promising?

## Canva Build Inputs

Page count target:

Format:

Print size or digital size:

Color direction:

Font direction:

Included files:

Delivery method:

## Proof Inputs

Competitor references reviewed:

What buyers praised:

What buyers complained about:

What gap your product fills:

## Final Product Check

Can a buyer understand what this is in 5 seconds?

Can a beginner use it without asking for help?

Does every page have a job?

Are all claims honest and specific?

