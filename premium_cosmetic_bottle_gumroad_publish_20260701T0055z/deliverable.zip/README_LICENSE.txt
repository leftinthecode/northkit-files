Premium Cosmetic Bottle 3D Product Twin GLB

Included files:
- premium_cosmetic_bottle.glb: optimized product-twin model for web/ecommerce/AR preview workflows.
- premium_cosmetic_bottle.blend: editable Blender source file.
- qa_manifest.json: production proof and QA notes.
- previews/: four preview renders.

Use cases:
- ecommerce product visualization mockups
- web/AR product previews
- product-twin pipeline reference
- lighting/material study for cosmetics packaging

License:
Royalty-free commercial use for renders, mockups, demos, and internal ecommerce workflows.
Do not resell or redistribute the raw files as-is or claim exclusive ownership of the base asset.
This asset contains no customer logo, no trademarked brand, and no exclusive identity mark.

Support:
Contact Nash VSW through the store/contact channel where you purchased this file.
