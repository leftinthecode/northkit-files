# Next Product Ladder

Ready for production: yes
Public action allowed: no

## Ranked Next Offers

### 1. etsy_listing_rescue_prompt_pack
Prompt and checklist pack that diagnoses weak Etsy digital listings and rewrites title, tags, description, FAQ, and preview-image briefs.

Buyer: digital seller with products posted but low clicks or low conversion
Why next: Narrow urgent pain beats generic prompt dumps and creates a clear before/after value story.

Proof needed:
- [ ] before/after listing sample
- [ ] keyword-intent map
- [ ] unsupported-claims audit

Stop ship if:
- [ ] cannot show a useful before/after sample
- [ ] copy sounds like unsupported outcome promises

### 2. canva_digital_product_launch_prompt_pack
Prompt workflow for turning one idea into Canva worksheet/checklist/template specs, buyer instructions, and listing preview copy.

Buyer: beginner creator who wants a digital product but does not know what pages to make
Why next: Connects prompts to an actual product-building workflow, increasing perceived utility.

Proof needed:
- [ ] sample template spec
- [ ] beginner quick-start
- [ ] file/export checklist

Stop ship if:
- [ ] too broad across every Canva product
- [ ] no sample output

### 3. pinterest_traffic_for_etsy_sellers_prompt_pack
Pin title, description, board, content calendar, and analytics prompts for driving ethical traffic to digital downloads.

Buyer: Etsy seller needing off-platform traffic without duplicate spam
Why next: Distribution pain follows product/listing pain and supports repeat customers.

Proof needed:
- [ ] non-duplicate pin draft set
- [ ] keyword cluster
- [ ] 14-day content plan

Stop ship if:
- [ ] duplicate social drafts
- [ ] traffic claims without analytics caveat

### 4. digital_download_customer_support_prompt_pack
Support, FAQ, refund-risk, onboarding, and update-note prompt pack for digital download sellers.

Buyer: seller trying to reduce confusion, refunds, and support time
Why next: Customer success proof strengthens trust and can bundle with all seller products.

Proof needed:
- [ ] support scripts
- [ ] refund-safe expectation language
- [ ] troubleshooting sheet

Stop ship if:
- [ ] policy language is vague
- [ ] buyer instructions are missing

## Rule

Use this ladder to choose the next product build; do not claim demand until fresh evidence is checked.
