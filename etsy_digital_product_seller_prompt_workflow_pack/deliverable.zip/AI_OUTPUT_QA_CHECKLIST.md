# AI Output QA Checklist

Before using any AI output, check:

- Specific to the buyer and product
- No copied competitor wording
- No trademark misuse
- No sales, income, ranking, review, or traffic promises
- Clear next step a seller can execute
- Fits the platform field length and policy
- Honest about what is included and not included
- Preview image or product file matches the listing claim
