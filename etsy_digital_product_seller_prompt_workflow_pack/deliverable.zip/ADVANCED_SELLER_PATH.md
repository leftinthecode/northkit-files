# Advanced Seller Path

1. Audit an existing product using the quality-gate prompts.
2. Compare views, clicks, favorites, and questions.
3. Rework offer, listing promise, preview images, and support copy.
4. Build a bundle or upsell only when the core product is clear.
5. Track before/after metrics for at least 7 days.
