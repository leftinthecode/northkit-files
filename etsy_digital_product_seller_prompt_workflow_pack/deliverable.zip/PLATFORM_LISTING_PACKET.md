# Platform Listing Packet

Title: 64+ ChatGPT Prompts for Etsy Digital Product Sellers
Price: $19.99
Public action allowed: no
Delivery ZIP: D:\Nash_Products\ai_prompt_packs\etsy_digital_product_seller_prompt_workflow_pack\delivery\etsy_digital_product_seller_prompt_workflow_pack.zip
Cover: D:\Nash_Products\ai_prompt_packs\etsy_digital_product_seller_prompt_workflow_pack\preview_images\cover.png

## Platform Upload Checklist

### lemon_squeezy
Fit: clean owned-store digital checkout with license keys not needed

- [ ] Create digital product draft
- [ ] Attach delivery ZIP
- [ ] Upload cover and carousel images
- [ ] Paste title, description, tags, price
- [ ] Keep product unpublished until Lee approves preview

Owner gates:
- [ ] login/2FA
- [ ] store payout/tax readiness
- [ ] final preview approval

### gumroad
Fit: fast digital download checkout and existing Nash product flow

- [ ] Create draft product
- [ ] Attach delivery ZIP or secure delivery URL
- [ ] Upload cover image
- [ ] Paste safe public description
- [ ] Keep unpublished until checkout/delivery proof is verified

Owner gates:
- [ ] account auth
- [ ] thumbnail proof
- [ ] delivery proof
- [ ] final preview approval

### etsy
Fit: buyer search demand for digital seller resources, but higher setup/review burden

- [ ] Create digital listing draft
- [ ] Attach ZIP if file size allows or split delivery files
- [ ] Upload cover and carousel images
- [ ] Use tags without keyword stuffing
- [ ] Keep listing draft-only until shop/profile and policies are correct

Owner gates:
- [ ] shop readiness
- [ ] digital file limits
- [ ] policy/review approval

## Rule

Platform packet prepares copy/assets only. It cannot create, upload, publish, spend, or message.
