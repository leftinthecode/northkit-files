# Pinterest Save-Worthiness Gate

Score: 7/7
Ready for Pinterest testing: yes

## Save Intent

A strong product pin gives the viewer a reason to save it for later: inspiration, instruction, comparison, checklist value, or a workflow they expect to use.

## Checks

- [x] clear_future_use: Does the product give a Pinterest viewer a practical reason to save the pin for later?
  Why: Saves usually come from future-use value, not exposure alone.
- [x] visible_product_proof: Is there a real cover/preview asset that can be shown instead of vague marketing?
  Why: Pins need visual proof of the offer.
- [x] style_or_design_pull: Does the product have at least one preview asset to carry visual style?
  Why: Pinterest is visual first; weak previews reduce saves.
- [x] functional_value_add: Does listing copy explain a concrete buyer outcome or included utility?
  Why: Useful pins promise a specific job-to-be-done.
- [x] keyword_and_board_fit: Do title/tags provide enough keyword material for buyer-relevant boards?
  Why: Saves from the wrong audience do not help the product.
- [x] non_duplicate_angle: Is the product's social duplicate preflight clean?
  Why: Repeated pins weaken trust and may look automated.
- [x] honest_click_path: Does the copy avoid guaranteed income/sales claims?
  Why: The pin should earn saves and clicks through truthful value.

## Traffic Truth

Views are exposure. Saves are interest. Clicks are intent. Sales are proof. Do not treat saves alone as revenue.

## Repair Rule

Fix failed checks before using Pinterest traffic for this product.
