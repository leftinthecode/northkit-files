# Claims Delivery Map

| Claim type | Allowed? | Required proof |
|---|---:|---|
| Instant digital download | Yes | ZIP/PDF attached to platform |
| Helps draft listing assets | Yes | Prompts and examples included |
| Helps with SEO wording | Yes | SEO prompts included |
| Outcome promises outside seller control | No | Never claim this |
| Rank or review outcomes | No | Never claim this |
| Beginner-friendly | Yes | Quick start and selection map included |
