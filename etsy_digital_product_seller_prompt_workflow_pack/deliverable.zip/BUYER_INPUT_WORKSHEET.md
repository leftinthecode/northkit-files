# Buyer Input Worksheet

Fill this before using the prompts.

- Product type:
- Target buyer:
- Buyer pain or desired outcome:
- Platform: Etsy / Gumroad / Shopify / other
- Skill level: beginner / intermediate / advanced
- Product format: PDF / Canva template / prompt pack / printable / SVG / bundle
- Current blocker: niche, offer, listing, SEO, visuals, support, or quality
- Time available today:
- Price target:
- What should not be promised:
