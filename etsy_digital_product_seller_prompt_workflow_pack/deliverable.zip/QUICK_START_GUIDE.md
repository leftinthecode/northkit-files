# Quick Start Guide

Use this pack like a step-by-step seller workflow, not like a random prompt library.

## 10 Minute First Win

1. Open `Niche Selection And Buyer Fit`.
2. Run the first prompt with one product idea you already have.
3. Copy the output into a note called `Product Decision`.
4. Run the `buyer promise` prompt with the strongest idea.
5. Move to `Etsy Listing Strategy` only after the buyer promise is clear.

## How To Fill The Brackets

- `[ETSY_PRODUCT]`: the exact product you want to sell, such as `printable habit tracker`.
- `[BUYER_PERSONA]`: the specific person buying, such as `busy mom starting a home budget`.
- `[PRICE_POINT]`: your intended price or range, such as `$9 to $19`.
- `[TIME_AVAILABLE]`: how much time the buyer has, such as `20 minutes per week`.
- `[SKILL_LEVEL]`: beginner, intermediate, or advanced.

## Example

Prompt to use:

Act as a market research strategist with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: score 10 digital product ideas by buyer pain, repeat use, proof strength, and production speed for [ETSY_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: a ranked table with go/no-go notes. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

Example inputs:

- `[ETSY_PRODUCT]`: printable digital product launch checklist
- `[BUYER_PERSONA]`: beginner Etsy seller with no audience
- `[PRICE_POINT]`: $12
- `[TIME_AVAILABLE]`: 2 hours this weekend
- `[SKILL_LEVEL]`: beginner

## Buyer Rule

Do not run every prompt at once. Pick the section that matches the current bottleneck: idea, listing, traffic, support, or quality.
