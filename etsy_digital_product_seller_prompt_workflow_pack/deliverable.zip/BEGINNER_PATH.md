# Beginner Path

1. Fill the buyer input worksheet.
2. Run one niche-fit prompt.
3. Run one product-creation prompt.
4. Draft one listing title, tags, and description.
5. Run the QA checklist.
6. Improve one weak section before publishing.
