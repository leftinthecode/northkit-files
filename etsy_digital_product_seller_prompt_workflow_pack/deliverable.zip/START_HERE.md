# Start Here

This digital product is built for sellers who want a clearer workflow before changing a listing, template, pin plan, support system, or bundle offer.

## Fastest Path

1. Open `QUICK_START_GUIDE.md` first if it exists.
2. Review the main prompt pack or bundle manifest.
3. Pick one product, listing, pin, support problem, or customer workflow to improve.
4. Run one prompt at a time and save the before version, prompt output, final edit, and date changed.
5. Use the checklist/support files before publishing any public change.

## Product

64+ ChatGPT Prompts for Etsy Digital Product Sellers

## Important

This is a digital download. It does not guarantee sales, traffic, ranking, income, platform approval, or customer reactions.

## Current best workflow

Use `BUYER_INPUT_WORKSHEET.md` first, then `PROMPT_SELECTION_MAP.md`, then the relevant prompt category. Run `AI_OUTPUT_QA_CHECKLIST.md` before publishing any buyer-facing copy.
