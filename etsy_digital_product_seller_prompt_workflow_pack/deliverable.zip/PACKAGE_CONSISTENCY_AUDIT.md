# Package Consistency Audit

Ready: yes
ZIP exists: yes
ZIP files: 15
Listing included files: 9

## Mismatches

### missing_from_zip
- none

### useful_unlisted_added
- none

## Rule

Package consistency can update draft listing file lists, but it cannot approve publishing.
