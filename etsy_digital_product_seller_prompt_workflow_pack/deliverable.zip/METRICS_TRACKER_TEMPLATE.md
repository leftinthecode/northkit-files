# Metrics Tracker Template

Track every product change.

| Date | Product | Changed | Views | Clicks | Favorites | Carts | Orders | Buyer questions | Refunds | Next action |
|---|---|---|---:|---:|---:|---:|---:|---|---:|---|
