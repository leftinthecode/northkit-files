# Prompt Selection Map

## If starting from zero

Use Niche Selection -> Prompt Product Creation -> Pricing/Offer -> Etsy Listing Strategy -> Quality Gate.

## If views are low

Use SEO And Traffic -> Etsy Listing Strategy -> Preview Sheet -> Quality Gate.

## If clicks happen but no sales

Use Pricing, Offer, And Bundle -> Customer Success And Support -> Listing Strategy.

## If support questions repeat

Use Customer Success And Support -> Quality Gate -> Product revision notes.
