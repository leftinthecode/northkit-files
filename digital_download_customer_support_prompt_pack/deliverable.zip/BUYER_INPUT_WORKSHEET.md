# Buyer Input Worksheet

Fill this out before running support prompts.

Product type:

Platform:

Buyer skill level:

Included files:

Delivery method:

Common buyer question:

Common buyer mistake:

Refund policy summary:

Support tone:

Response time expectation:

Known limitations:

What the product does not include:

## Support Proof Inputs

Top repeated issue:

Most confusing instruction:

File compatibility notes:

What buyers should do first:

Where buyers should go for help:

