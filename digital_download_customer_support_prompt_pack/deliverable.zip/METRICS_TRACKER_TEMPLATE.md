# Support Metrics Tracker

| Date | Product | Platform | Issue Type | Buyer Question | Reply Used | Resolved? | Product Fix Needed? | Notes |
|---|---|---|---|---|---|---|---|---|
| YYYY-MM-DD | Product name | Gumroad/Etsy/etc. | Access/File/Instructions/Refund/Other | Short summary | Script name | Yes/No | Yes/No | Notes |

## What To Watch

Repeated access questions:

Improve delivery instructions and file names.

Repeated usage questions:

Improve Start Here, FAQ, and preview copy.

Repeated refund concerns:

Check whether listing claims, file type, or buyer expectations are unclear.

Positive buyer replies:

Save language patterns that helped and reuse them.

