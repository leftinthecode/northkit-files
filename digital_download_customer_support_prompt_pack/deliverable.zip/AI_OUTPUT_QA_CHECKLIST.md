# AI Output QA Checklist

Review every AI-generated support reply before sending it.

## Accuracy

- The reply matches the actual product and files.
- The reply does not invent features, formats, bonuses, refunds, or policies.
- The buyer is given clear next steps.

## Tone

- Calm.
- Specific.
- Respectful.
- Short enough to read quickly.
- No blame or sarcasm.

## Policy Safety

- No legal threats.
- No guarantee of refund/dispute result.
- No promise outside the platform policy.
- No fake urgency or fake scarcity.

## Improvement Loop

- If the issue repeats, update instructions.
- If the listing caused confusion, fix the listing.
- If a file caused confusion, rename or restructure the delivery.

