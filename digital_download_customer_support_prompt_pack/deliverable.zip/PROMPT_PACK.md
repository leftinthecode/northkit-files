# Digital Download Customer Support AI Prompt Pack

A focused workflow prompt pack for reducing buyer confusion, support risk, and refund friction for digital downloads. It helps sellers write onboarding, FAQs, troubleshooting scripts, refund-safe responses, update notes, and support trackers. It does not provide legal advice or guarantee fewer refunds.

## Buyer Onboarding

### 1. Prompt

Act as a digital download customer success manager with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: write first-10-minute onboarding steps for [DIGITAL_PRODUCT] so buyers know what to open first for [DIGITAL DOWNLOADS_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: onboarding guide. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

### 2. Prompt

Act as a digital download customer success manager with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: turn [INCLUDED_FILES] into a plain-English file map with when to use each file for [DIGITAL DOWNLOADS_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: file map. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

### 3. Prompt

Act as a digital download customer success manager with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: write download instructions for [PLATFORM] that reduce confusion without blaming the buyer for [DIGITAL DOWNLOADS_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: download instructions. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

### 4. Prompt

Act as a digital download customer success manager with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: create a quick-win path for [BUYER_PERSONA] using [PRODUCT] in under 10 minutes for [DIGITAL DOWNLOADS_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: quick-win steps. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

### 5. Prompt

Act as a digital download customer success manager with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: write a welcome note for [DIGITAL_PRODUCT] that sets honest expectations for [DIGITAL DOWNLOADS_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: welcome note. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

### 6. Prompt

Act as a digital download customer success manager with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: create beginner, intermediate, and advanced first-use paths for [PRODUCT] for [DIGITAL DOWNLOADS_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: path options. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

### 7. Prompt

Act as a digital download customer success manager with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: audit [BUYER_INSTRUCTIONS] for missing steps and confusing wording for [DIGITAL DOWNLOADS_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: instruction audit. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

### 8. Prompt

Act as a digital download customer success manager with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: write a one-page start-here guide for [PRODUCT_FAMILY] for [DIGITAL DOWNLOADS_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: start-here page. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

## FAQ And Expectation Setting

### 1. Prompt

Act as a digital product FAQ copywriter with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: write an FAQ for [DIGITAL_PRODUCT] covering files, access, usage, printing, editing, and support for [DIGITAL DOWNLOADS_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: FAQ section. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

### 2. Prompt

Act as a digital product FAQ copywriter with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: turn [CUSTOMER_QUESTIONS] into clear policy-safe answers for [DIGITAL DOWNLOADS_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: answer bank. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

### 3. Prompt

Act as a digital product FAQ copywriter with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: write expectation language for [PRODUCT] that avoids income or outcome guarantees for [DIGITAL DOWNLOADS_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: expectation copy. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

### 4. Prompt

Act as a digital product FAQ copywriter with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: create an included/not-included section for [DIGITAL_DOWNLOAD] for [DIGITAL DOWNLOADS_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: included limits copy. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

### 5. Prompt

Act as a digital product FAQ copywriter with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: write refund-safe wording for buyers who expected a physical product for [DIGITAL DOWNLOADS_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: support response. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

### 6. Prompt

Act as a digital product FAQ copywriter with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: audit [LISTING_COPY] for unclear delivery promises and refund-risk language for [DIGITAL DOWNLOADS_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: risk audit. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

### 7. Prompt

Act as a digital product FAQ copywriter with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: write support copy for editable vs non-editable files for [DIGITAL DOWNLOADS_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: file rights explanation. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

### 8. Prompt

Act as a digital product FAQ copywriter with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: create a buyer checklist before purchase for [PRODUCT] for [DIGITAL DOWNLOADS_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: pre-purchase checklist. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

## Troubleshooting Scripts

### 1. Prompt

Act as a digital download support specialist with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: write troubleshooting steps for a buyer who cannot find the download email for [DIGITAL DOWNLOADS_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: support script. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

### 2. Prompt

Act as a digital download support specialist with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: write troubleshooting steps for opening a ZIP file on phone and desktop for [DIGITAL DOWNLOADS_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: ZIP support guide. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

### 3. Prompt

Act as a digital download support specialist with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: write support copy for PDF printing, scaling, and page size confusion for [DIGITAL DOWNLOADS_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: PDF support guide. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

### 4. Prompt

Act as a digital download support specialist with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: write support copy for Canva link access problems for [DIGITAL DOWNLOADS_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: Canva access guide. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

### 5. Prompt

Act as a digital download support specialist with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: create a polite response when a buyer says the file is not what they expected for [DIGITAL DOWNLOADS_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: support response. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

### 6. Prompt

Act as a digital download support specialist with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: write a replacement-download verification checklist for [DIGITAL DOWNLOADS_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: verification checklist. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

### 7. Prompt

Act as a digital download support specialist with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: audit [SUPPORT_SCRIPT] for defensive tone and unclear next steps for [DIGITAL DOWNLOADS_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: tone audit. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

### 8. Prompt

Act as a digital download support specialist with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: create a support escalation rule for platform messages for [DIGITAL DOWNLOADS_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: escalation rule. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

## Refund Risk And Policy Safety

### 1. Prompt

Act as a digital product policy-safe support lead with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: identify refund risks in [PRODUCT_PAGE] and suggest listing fixes before launch for [DIGITAL DOWNLOADS_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: refund risk table. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

### 2. Prompt

Act as a digital product policy-safe support lead with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: write a policy-safe response to a refund request for [DIGITAL_PRODUCT] for [DIGITAL DOWNLOADS_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: refund response. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

### 3. Prompt

Act as a digital product policy-safe support lead with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: create expectation wording that explains instant digital delivery without sounding harsh for [DIGITAL DOWNLOADS_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: policy copy. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

### 4. Prompt

Act as a digital product policy-safe support lead with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: audit [FAQ] for promises that could cause refund disputes for [DIGITAL DOWNLOADS_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: FAQ risk audit. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

### 5. Prompt

Act as a digital product policy-safe support lead with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: write buyer-friendly language for no physical item, file compatibility, and personal-use limits for [DIGITAL DOWNLOADS_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: policy-safe section. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

### 6. Prompt

Act as a digital product policy-safe support lead with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: create a decision tree for refund, replacement, education, or escalation for [DIGITAL DOWNLOADS_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: decision tree. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

### 7. Prompt

Act as a digital product policy-safe support lead with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: write a support note for accidental duplicate purchase for [DIGITAL DOWNLOADS_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: support response. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

### 8. Prompt

Act as a digital product policy-safe support lead with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: create a release gate that checks refund-risk copy before publishing for [DIGITAL DOWNLOADS_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: release gate. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

## Updates And Repeat Buyers

### 1. Prompt

Act as a digital product retention strategist with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: write version update notes for improving [PRODUCT] after launch for [DIGITAL DOWNLOADS_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: update notes. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

### 2. Prompt

Act as a digital product retention strategist with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: create a customer feedback request that does not pressure for reviews for [DIGITAL DOWNLOADS_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: feedback request. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

### 3. Prompt

Act as a digital product retention strategist with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: turn support questions into product improvement tasks for [DIGITAL DOWNLOADS_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: improvement backlog. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

### 4. Prompt

Act as a digital product retention strategist with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: write cross-sell copy from [PRODUCT_A] to [PRODUCT_B] after a support interaction for [DIGITAL DOWNLOADS_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: cross-sell copy. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

### 5. Prompt

Act as a digital product retention strategist with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: create a repeat-buyer onboarding note for a product bundle for [DIGITAL DOWNLOADS_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: bundle note. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

### 6. Prompt

Act as a digital product retention strategist with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: write a product update announcement that explains what changed and why for [DIGITAL DOWNLOADS_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: announcement. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

### 7. Prompt

Act as a digital product retention strategist with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: build a support-to-content idea list from [CUSTOMER_MESSAGES] for [DIGITAL DOWNLOADS_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: content ideas. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

### 8. Prompt

Act as a digital product retention strategist with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: create a 30-day customer success loop for digital products for [DIGITAL DOWNLOADS_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: operating cadence. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

## Support Metrics And Learning

### 1. Prompt

Act as a customer support analytics operator with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: create a support tracker for question type, product, resolution, refund risk, and product fix for [DIGITAL DOWNLOADS_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: tracker columns. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

### 2. Prompt

Act as a customer support analytics operator with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: diagnose whether support issues come from listing copy, delivery, files, or buyer mismatch for [DIGITAL DOWNLOADS_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: root-cause report. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

### 3. Prompt

Act as a customer support analytics operator with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: turn [SUPPORT_LOG] into top product improvements ranked by buyer pain for [DIGITAL DOWNLOADS_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: ranked fixes. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

### 4. Prompt

Act as a customer support analytics operator with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: define when support volume means a product should be revised before more traffic for [DIGITAL DOWNLOADS_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: hold rule. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

### 5. Prompt

Act as a customer support analytics operator with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: write a weekly support review checklist for [PRODUCT_FAMILY] for [DIGITAL DOWNLOADS_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: review checklist. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

### 6. Prompt

Act as a customer support analytics operator with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: create analytics notes separating buyer confusion from true product defects for [DIGITAL DOWNLOADS_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: learning notes. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

### 7. Prompt

Act as a customer support analytics operator with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: build a dashboard spec for support risk across digital products for [DIGITAL DOWNLOADS_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: dashboard spec. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

### 8. Prompt

Act as a customer support analytics operator with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: write a pivot rule if support issues keep repeating for [DIGITAL DOWNLOADS_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: pivot rule. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

## Quality Gate And Trust Proof

### 1. Prompt

Act as a digital product trust and QA auditor with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: grade [DIGITAL_PRODUCT] for buyer clarity, file usability, support readiness, and trust proof for [DIGITAL DOWNLOADS_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: 100-point scorecard. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

### 2. Prompt

Act as a digital product trust and QA auditor with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: audit [DELIVERY_ZIP] contents against listing promises for [DIGITAL DOWNLOADS_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: delivery match audit. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

### 3. Prompt

Act as a digital product trust and QA auditor with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: write pre-publish support-readiness checks for [PRODUCT] for [DIGITAL DOWNLOADS_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: support release gate. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

### 4. Prompt

Act as a digital product trust and QA auditor with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: create proof bullets that show support readiness without overclaiming for [DIGITAL DOWNLOADS_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: trust bullets. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

### 5. Prompt

Act as a digital product trust and QA auditor with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: audit [PRODUCT] for missing instructions, broken file map, and confusing buyer rights for [DIGITAL DOWNLOADS_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: QA report. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

### 6. Prompt

Act as a digital product trust and QA auditor with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: write a buyer-safe limitations section for [PRODUCT] for [DIGITAL DOWNLOADS_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: limitations copy. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

### 7. Prompt

Act as a digital product trust and QA auditor with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: create a product retirement or revision rule based on support evidence for [DIGITAL DOWNLOADS_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: revision rule. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.

### 8. Prompt

Act as a digital product trust and QA auditor with 10+ years experience helping digital sellers launch profitable, ethical downloads. Your tone is practical, specific, and buyer-outcome focused. Compliance requirements: no fake income claims, no copied competitor wording, no trademark misuse, and no promises of guaranteed sales. Task: write final Lee approval checklist for customer-success readiness for [DIGITAL DOWNLOADS_PRODUCT] targeting [BUYER_PERSONA] with [PRICE_POINT], [TIME_AVAILABLE], and [SKILL_LEVEL]. Return as: approval checklist. Include: assumptions, exact next actions, examples, and a warning section for common mistakes. Length: medium. Ask for missing inputs only if they materially change the result.
