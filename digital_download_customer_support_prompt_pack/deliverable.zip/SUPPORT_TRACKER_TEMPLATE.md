# Support Tracker Template

| Date | Platform | Product | Question type | Buyer words | Likely root cause | Response sent | Resolved yes/no | Refund risk | Product/listing fix needed |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
