# Support Decision Tree

Use this before replying to a buyer.

## Buyer Cannot Access The File

Run:

1. Buyer onboarding prompt
2. File access troubleshooting prompt
3. Clear next-step reply prompt

Check:

- Did the buyer receive the download link?
- Are they logged into the right account?
- Are file names clear?
- Is the reply platform-safe and calm?

## Buyer Does Not Understand How To Use The Product

Run:

1. Plain-English instruction prompt
2. Beginner walkthrough prompt
3. FAQ improvement prompt

Check:

- Is the product missing a Start Here file?
- Does the listing overpromise ease of use?
- Should instructions be updated for future buyers?

## Buyer Requests A Refund

Run:

1. Refund-risk and policy-safety prompt
2. Clarifying question prompt
3. Resolution options prompt

Check:

- Do not argue.
- Do not promise an outcome outside platform policy.
- Keep records of what happened.
- Improve listing or delivery if the issue is preventable.

## Buyer Reports A Broken Or Missing File

Run:

1. Troubleshooting script prompt
2. Replacement delivery note prompt
3. Product update announcement prompt

Check:

- Verify the file locally.
- Fix the product package if needed.
- Update FAQ and listing details.

## Buyer Gives Helpful Feedback

Run:

1. Support metrics prompt
2. Post-launch learning prompt
3. Repeat-buyer update prompt

Check:

- Log the issue.
- Decide whether it affects product quality.
- Turn repeated questions into better instructions.

