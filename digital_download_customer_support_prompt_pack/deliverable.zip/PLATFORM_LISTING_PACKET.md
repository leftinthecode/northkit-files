# Platform Listing Packet

Title: 56+ Digital Download Customer Support ChatGPT Prompts for Sellers
Price: $14.99
Public action allowed: no
Delivery ZIP: D:\Nash_Products\ai_prompt_packs\digital_download_customer_support_prompt_pack\delivery\digital_download_customer_support_prompt_pack.zip
Cover: D:\Nash_Products\ai_prompt_packs\digital_download_customer_support_prompt_pack\preview_images\cover.png

## Platform Upload Checklist

### gumroad
Fit: fastest draft checkout for digital download testing

- [ ] Create draft product
- [ ] Attach delivery ZIP
- [ ] Upload cover image
- [ ] Paste listing copy
- [ ] Keep unpublished until delivery proof is verified

Owner gates:
- [ ] account auth
- [ ] checkout preview
- [ ] secure delivery proof
- [ ] final approval

### lemon_squeezy
Fit: clean owned-store checkout once profile/store setup is confirmed

- [ ] Create digital product draft
- [ ] Attach delivery ZIP
- [ ] Upload cover and carousel
- [ ] Paste price and copy
- [ ] Keep unpublished until Lee approves

Owner gates:
- [ ] login/2FA
- [ ] payout/tax readiness
- [ ] final preview approval

### etsy
Fit: marketplace search fit after shop policy/profile readiness

- [ ] Create digital listing draft
- [ ] Attach ZIP or split files
- [ ] Upload preview images
- [ ] Use tags without stuffing
- [ ] Keep listing draft-only

Owner gates:
- [ ] shop readiness
- [ ] file-size check
- [ ] policy/review approval

## Rule

Platform packet prepares listing assets only. It cannot create, upload, publish, spend, or message.
