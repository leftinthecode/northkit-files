# Support Script Bank Sample

## Cannot Find Download

Thanks for reaching out. The download is usually available from your receipt or account purchase page. Please check the email used at checkout first. If it is still missing, send the order email/address and I will help verify the delivery path through the platform.

## Expected Physical Product

This listing is for a digital download, so no physical item ships. I understand the confusion. The included files are listed in the product description, and I can help you locate or open them.

## ZIP File Help

If you are on a phone, try saving the ZIP to Files first, then tap to extract. On desktop, right-click the ZIP and choose Extract All. If the file still will not open, tell me your device type and I will help narrow it down.