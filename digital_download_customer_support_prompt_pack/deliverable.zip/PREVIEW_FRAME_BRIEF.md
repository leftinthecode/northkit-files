# Preview Frame Brief

Use these frames for marketplace previews, Gumroad/Lemon Squeezy images, Pinterest pins, or listing screenshots.

## Frame 1: Cover

Show the product name and the exact buyer/workflow it helps.

56+ Digital Download Customer Support ChatGPT Prompts for Sellers

## Frame 2: What Is Inside

Show the included files, prompt categories, checklist, guide, or bundle parts. Make it obvious this is a digital download.

## Frame 3: How To Use

Show a simple workflow:

Diagnose -> Draft -> Check -> Publish carefully -> Measure -> Improve

## Frame 4: Example Or Proof

Show a short before/after, sample prompt, file map, checklist, or workflow screenshot. Keep it honest and avoid outcome guarantees.

## Frame 5: Trust And Limits

Include clear expectations:

- Digital download only
- No physical product ships
- No sales, income, ranking, traffic, or platform approval guarantee
- Built for original work, not copying competitors

## Save-Worthy Angle

A good preview answers: what problem does this help me fix, what will I use first, what files do I get, and why should I save this for later?
