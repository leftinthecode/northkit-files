# Claims Delivery Map

| Public Claim | Delivery Proof |
|---|---|
| 56 support prompts | `PROMPT_PACK.md`, `prompt_pack.pdf`, and `prompt_pack.json` include 56 prompts across 7 support categories. |
| Helps digital download sellers | Categories cover onboarding, FAQ, troubleshooting, refund-risk language, repeat buyers, metrics, and trust proof. |
| Includes support scripts | `SUPPORT_SCRIPT_BANK.md` is included. |
| Includes tracking workflow | `SUPPORT_TRACKER_TEMPLATE.md` and support metrics prompts are included. |
| Policy-safe language | Refund-risk and policy-safety prompts plus `AI_OUTPUT_QA_CHECKLIST.md` are included. |
| No guaranteed outcomes | Public copy avoids guaranteed sales, reviews, refund reduction, dispute wins, or buyer satisfaction claims. |

## Claim Rule

If a claim is not backed by a file, remove it or add the missing support proof before publishing.

