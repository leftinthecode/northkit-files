# Proof Board Guide

Every proof board should answer:
- What is the buyer job?
- What is included?
- What is not included?
- What proof did we inspect?
- What competitor references were checked?
- What claim limits are active?
- What is the next measured test?

Minimum proof before public promotion:
- Product page screenshot.
- Delivery ZIP opens successfully.
- Preview image matches actual contents.
- No unsupported income, ranking, or outcome guarantees.
- One metric checkpoint is scheduled.
