# Example Run: Digital Listing Rescue Sample

Product:
Digital listing audit and rewrite checklist.

Buyer job:
The seller has views but weak buyer trust and unclear delivery wording.

Weak gate:
Offer clarity. The title names a broad product but does not explain the buyer outcome.

Repair:
Rewrite the title around the buyer job, add a before/after preview, and add claim limits.

Decision:
Private A1 validation-ready only after the delivery proof and buyer intake are present.
