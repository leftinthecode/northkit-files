# Quick Start

1. Pick one product or content asset.
2. Fill the product facts section in the proof board.
3. Score all six gates from 0 to 5.
4. Fix the lowest gate first.
5. Only mark the product A1 validation-ready if it reaches 90 or higher.
6. Only scale traffic if the product reaches 95 or higher and platform proof is current.

Beginner route:
- Use the checklist and scorecard only.
- Add short notes for each score.

Advanced route:
- Add competitor references.
- Add screenshots or file-open proof.
- Add a seven-day metric check after posting.
