# Claim Limits And Safe Use

Allowed claims:
- Helps organize product QA.
- Helps identify weak buyer-trust signals.
- Helps create a proof board and repair checklist.
- Designed for small measured validation tests.

Not allowed:
- Guaranteed sales.
- Guaranteed ranking.
- Guaranteed income.
- Automated platform bypass.
- Unsolicited buyer messaging.
- Claims that the product is a substitute for legal, tax, or platform-policy advice.
