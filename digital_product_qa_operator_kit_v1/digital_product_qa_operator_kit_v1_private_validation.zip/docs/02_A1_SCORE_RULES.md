# A1 Score Rules

Six gates:
1. Buyer need proof
2. Offer clarity
3. Artifact quality
4. Competitor parity
5. Claim and delivery safety
6. Launch test readiness

Scoring:
- 0 means missing.
- 1 means weak.
- 2 means incomplete.
- 3 means usable but not trusted.
- 4 means strong private validation.
- 5 means strong enough for scale proof.

Decision:
- 95 to 100: scale candidate after platform preview proof.
- 90 to 94: private A1 validation or small measured test.
- 75 to 89: repair before public promotion.
- Below 75: hold, retire, or rebuild.
