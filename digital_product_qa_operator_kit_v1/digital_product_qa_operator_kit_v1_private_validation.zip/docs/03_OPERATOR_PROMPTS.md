# Operator Prompts

Use these prompts in order. Replace bracketed text with your product facts.

## Product Facts
1. Identify the exact buyer for [product] and list the painful job they need done.
2. Rewrite this product promise so it is specific, honest, and buyer-facing: [promise].
3. List what a buyer must inspect before trusting [product].
4. Identify what would make [product] feel generic or low trust.

## A1 QA
5. Score buyer need from 0 to 5 and require evidence for the score.
6. Score offer clarity from 0 to 5 using title, cover, preview, and first two description lines.
7. Score artifact quality from 0 to 5 after opening or testing every deliverable.
8. Score competitor parity from 0 to 5 against at least three relevant references.
9. Score claim safety from 0 to 5 and remove unsupported claims.
10. Score launch readiness from 0 to 5 using platform proof and a metric checkpoint.

## Repair
11. Find the weakest gate and give the smallest repair that raises buyer trust.
12. Rewrite the first screen so it explains outcome, contents, and limits.
13. Create a proof screenshot checklist for [product].
14. Create a delivery manifest that prevents buyer confusion.
15. Convert vague benefits into exact deliverables.
16. Create a conservative claim map for the listing.

## Launch Test
17. Write one proof-led post that does not guarantee income or ranking.
18. Write one platform description optimized for buyer clarity.
19. Create a seven-day metric checkpoint for views, clicks, saves, comments, and orders.
20. Decide whether the result should be scaled, repaired, retired, or used as a support asset.

## Customer Support
21. Draft a buyer intake form for missing facts.
22. Draft a delivery note that states what is included and what is not included.
23. Draft a polite clarification message when a buyer asks for unsupported work.
24. Draft a refund-prevention checklist based on preview clarity and delivery proof.
