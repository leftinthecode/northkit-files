# Digital Product QA Operator Kit V1

Use this kit to decide whether a digital product is ready to publish, needs a focused repair, or should stay private.

Best fit:
- Etsy, Gumroad, Fiverr, Pinterest, YouTube, and social media product builders.
- Small business owners who use AI but need a human review structure.
- Creators who want a repeatable proof board instead of another generic prompt list.

Not included:
- No sales guarantee.
- No ranking guarantee.
- No legal, tax, or platform-policy advice.
- No scraping, spam, or unsolicited buyer messaging workflow.

Start with `docs/01_QUICK_START.md`, then score the product in `templates/digital_product_qa_scorecard.csv`.
